#include "Il2CppSystem.h"

namespace Il2CppSystem
{
	const Il2CppAssembly* mscorlib;
	Il2CppClass* SystemType_Byte;
	Il2CppClass* SystemType_Int32;
	Il2CppClass* SystemType_Int64;
	Il2CppClass* SystemType_String;
	Il2CppClass* SystemType_Type;
	Il2CppClass* SystemType_Dictionary_2;
	MethodInfo* Type_MakeGeneric;
}