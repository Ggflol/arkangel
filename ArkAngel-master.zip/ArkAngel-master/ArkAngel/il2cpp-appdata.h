#pragma once
#include <cstdint>
#include "il2cpp-typedefs.h"

// IL2CPP APIs
#define DO_API(r, n, p) extern r (*n) p
#include "il2cpp-functions.h"
#undef DO_API
#include "il2cpp-generic-list.h"
#include "app-il2cpp-types.h"
