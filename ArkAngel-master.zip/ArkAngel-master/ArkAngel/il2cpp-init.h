#pragma once
void init_il2cpp();