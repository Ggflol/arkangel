#pragma once
#define NOMINMAX
#include "Framework.h"
#pragma warning(disable : 4996)
void Run(HMODULE hMod);

